# Tangazo Hub
Website ya Kiswahili yenye nafasi za matangazo.

## Kuweka matangazo
Nafasi zenye maandishi `NAFASI YA TANGAZO` ndizo slots za kuingiza code kutoka ad network utakayochagua.

## Muhimu
Usibofye matangazo yako mwenyewe na usihimize visitors kubofya matangazo. Fuata masharti ya ad network.
